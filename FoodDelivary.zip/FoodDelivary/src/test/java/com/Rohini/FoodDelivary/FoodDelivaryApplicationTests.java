package com.Rohini.FoodDelivary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDelivaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
